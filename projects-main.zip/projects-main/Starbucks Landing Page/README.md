<html>
  <head> </head> <body> <h1 align = center> Display</h1> <img src = "img/Display.png"> </body>
</html>
