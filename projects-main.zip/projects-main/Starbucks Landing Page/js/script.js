function imgSlider(anything){
  document.querySelector('.starbucks').src = anything;
}
